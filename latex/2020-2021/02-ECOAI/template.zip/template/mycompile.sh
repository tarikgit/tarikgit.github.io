#latex ocaktan_curriculum_oct2011_jobmarket
#latex ocaktan_curriculum_oct2011_jobmarket
#latex ocaktan_curriculum_oct2011_jobmarket
#dvips ocaktan_curriculum_oct2011_jobmarket.dvi
#ps2pdf ocaktan_curriculum_oct2011_jobmarket.ps
#acroread ocaktan_curriculum_oct2011_jobmarket.pdf &

latex slides
latex slides
latex slides
dvips slides.dvi
ps2pdf slides.ps
#acroread slides.pdf &
